# Countdown SPM Matematik 2026 - SMK Tekek

Fail utama: `index.html`

## Cara guna dengan GitHub Pages
1. Cipta repository baharu di GitHub, contoh: `countdown-spm-matematik`
2. Upload `index.html` ke root repository.
3. Pergi ke **Settings > Pages**
4. Di **Build and deployment**, pilih:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
5. Klik **Save**.
6. Tunggu 1–3 minit. GitHub akan paparkan URL laman anda.

Contoh URL:
`https://USERNAME.github.io/countdown-spm-matematik/`
